<?php
$db_username = 'a8718191_sushant';
$db_password = 'Sush1993';
$db_name = 'a8718191_abhivad';
$db_host = 'a8718191_000webhost.com';
$items_per_group = 4;
$mysqli = new mysqli($db_host, $db_username, $db_password,$db_name);
//Output any connection error
// if ($mysqli->connect_error) {
//     die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
// }

?>